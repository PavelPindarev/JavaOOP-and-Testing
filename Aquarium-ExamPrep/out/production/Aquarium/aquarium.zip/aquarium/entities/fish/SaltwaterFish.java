package aquarium.entities.fish;

public class SaltwaterFish extends BaseFish{
    private int size = 5;
    public SaltwaterFish(String name, String species, double price) {
        super(name, species, price);
        setSize(size);
    }
    @Override
    public void eat() {
        int newSize = this.size + 2;
        setSize(newSize);
    }
}
